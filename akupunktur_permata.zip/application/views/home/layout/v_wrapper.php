<?php
$this->load->view('/home/layout/v_head.php');
$this->load->view('/home/layout/v_header.php');
$this->load->view('/home/layout/v_nav.php');
$this->load->view('/home/layout/v_content.php');
$this->load->view('/home/layout/v_footer.php');
