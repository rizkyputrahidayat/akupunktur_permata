<div class="row">
    <div class="col-md-12">
        <div class="about-logo">
            <h3>Alur Prakerin SMKN 1 Batusangkar</h3>
            <p>Berikut Adalah Alur Prakerin pada SMKN 1 Batusangkatr</p>
            <p>1. Coaching oleh pihak Sekolah</p>
            <p>2. Meminta id dan password kepada Wakil Kepala Sekolah Bidang Humas / DUDI</p>
            <p>3. login ke website E-Prakerin SMKN 1 Batusangkar menggunkan id dan password yang diberikan oleh Wakil Kepala Sekolah bidang Humas / DUDI</p>
            <p>4. Melihat informasi Tempat Prakerin atau Perusahaan yang Terdaftar di list</p>
            <p>5. Jika Tempat Prakerin atau Perusahaan belum terdatar atau bekerja sama dengan pihak sekolah maka siswa bisa mengntrikan Perusahaan tersebut dengan syarat sudah melakukan konfirmasi terhadap perusaaan bersangkutan bahwa bisa menerima siswa Prakerin</p>
            <p>6. Memilih Perusahaan yang akan ditempati</p>
            <p>7. mengantarkan siswa atau peserta prakerin kepada perusahaan atau tempat prakerin oleh pembimbing</p>
            <p>7. Memulai Prakerin oleh siswa sesuai dengan waktu yang telah ditentukan</p>
            <p>8. Melakukan monitoring dan peyerahan form penilaian dan sertifikat peserta prakerin</p>
            <p>9. menjemput siswa atau peserta prakerin</p>
            <p>10. Membuat laporan prakerin oleh siswa dan diserahkan kepada pembimbing</p>
            <p>11. Menginputkan nilai siswa sesuai dengan ketentuan perhitungan niai oleh pembinmbing</p>
            <p>12. melihat transkrip nilai siswa</p>
        </div>
    </div>
</div>